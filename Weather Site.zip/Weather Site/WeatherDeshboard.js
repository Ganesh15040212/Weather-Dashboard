
const cityInput = document.querySelector(".city-input")
const searchButton = document.querySelector(".search-btn")
const locationButton = document.querySelector(".location-btn")
const currentWeather = document.querySelector(".current-weather")
const weatherCardDiv = document.querySelector(".weather-cards")

const API_KEY = "be77fca2ba7832430cba514ac205adc6"  // API key for openweathermap API

const createWeatherCard = (cityName, weatherItem, index) =>
{
    if (index === 0)   // HTML for the main weather card
    {
        return `<div class="col-12">
                    <div class="p-4 d-flex border border-3 rounded text-white" style="background: transparent; backdrop-filter: blur(5px);">
                        <div class="details d-grid flex-grow-1 ms-3">
                            <h2 class="fw-bold mb-4">${cityName} ( ${weatherItem.dt_txt.split(" ")[0]} )</h2>
                            <h5 class="fw-bold">Temperature : ${(weatherItem.main.temp - 273.15).toFixed(2)} ° C</h5>
                            <h5 class="fw-bold">Wind : ${weatherItem.wind.speed} M/S</h5>
                            <h5 class="fw-bold">Humidity : ${weatherItem.main.humidity} %</h5>
                        </div>
                        <div class="icon flex-shrink-0 me-5">
                            <img src="https://openweathermap.org/img/wn/${weatherItem.weather[0].icon}@4x.png" alt="Weather-icon">
                            <h4 class = "text-center">${weatherItem.weather[0].description}</h4>
                        </div>
                    </div>
                </div>`
    }
    else    // HTML for the other days forecast card
    {
        return `<li class="col-md-3 p-1 rounded mt-5 border border-3 rounded" style="background: transparent; backdrop-filter: blur(5px);">
                    <h3 class="fw-bold mt-3">( ${weatherItem.dt_txt.split(" ")[0]} )</h3>
                    <img src="https://openweathermap.org/img/wn/${weatherItem.weather[0].icon}@2x.png" alt="Weather-icon" class="mx-4">
                    <h6 class="fw-bold">Temperature : ${(weatherItem.main.temp - 273.15) . toFixed(2)} ° C</h6>
                    <h6 class="fw-bold">Wind : ${weatherItem.wind.speed} M/S</h6>
                    <h6 class="fw-bold">Humidity : ${weatherItem.main.humidity} %</h6>
                </li>`
    }
}

const getWeatherDeatils = (cityName, lat, lon) =>
{
    const WEATHER_API_URL = `http://api.openweathermap.org/data/2.5/forecast/?lat=${lat}&lon=${lon}&appid=${API_KEY}`

    fetch(WEATHER_API_URL).then(res => res.json()).then(data =>
    {
        const uniqueForecastDays = []
        const fiveDaysForecast = data.list.filter(forecast =>
        {
            const forecastDate = new Date(forecast.dt_txt).getDate()
            if (!uniqueForecastDays.includes(forecastDate))
            {
                return uniqueForecastDays.push(forecastDate)
            }
        })

        // Clearing previous weather data
        cityInput.value = ""
        weatherCardDiv.innerHTML = ""
        currentWeather.innerHTML = ""

        // console.log(fiveDaysForecast)

        // Creating weather cards and adding them to the DOM
        fiveDaysForecast.forEach((weatherItem, index) =>
        {
            const cardHTML = createWeatherCard(cityName, weatherItem, index);
            if (index === 0)
            {
                currentWeather.innerHTML = cardHTML; // For today's weather
            }
            else
            {
                weatherCardDiv.insertAdjacentHTML("beforeend", cardHTML); // For 5-day forecast
            }
        });

    })
    .catch(() =>
    {
        alert("An Error occured while featching the weather forecast!")
    })
}

const getCityCoordinates = () =>
{
    const cityName = cityInput.value.trim()
    if (!cityName)
        return;
    // console.log(cityName);
    const GEOCODING_API_URL = `http://api.openweathermap.org/geo/1.0/direct?q=${cityName}&limit=1&appid=${API_KEY}`

    fetch(GEOCODING_API_URL).then(res => res.json()).then(data =>
    {
        if (!data.length)
            return alert(`No Coordinates found for ${cityName}`)
        const { name, lat, lon } = data[0]
        getWeatherDeatils(name, lat, lon)
        // console.log(data)
    })
    .catch(() =>
    {
        alert("An Error occured while featching the Coordinates!")
    })
}

const getUserCoordinates = () =>
{
    navigator.geolocation.getCurrentPosition(
        position =>
        {
            const { latitude, longitude } = position.coords
            const REVERSE_GEOCODING_URL = `http://api.openweathermap.org/geo/1.0/reverse?lat=${latitude}&lon=${longitude}&limit=1&appid=${API_KEY}`

            // get city name from coordinates using reverse geocoding API
            fetch(REVERSE_GEOCODING_URL).then(res => res.json()).then(data =>
            {
                const { name } = data[0]
                getWeatherDeatils(name, latitude, longitude)
                // console.log(data)
            })
            .catch(() =>
            {
                alert("An Error occured while featching the city!")
            })
            // console.log(position);
        },
        error =>
        {
            if (error.code === error.PERMISSION_DENIED)
            {
                alert("Geolocation request denied. please reset location permission to grant access again..")
            }
            // console.log(error);
        }
    )
}

locationButton.addEventListener('click', getUserCoordinates)
searchButton.addEventListener('click', getCityCoordinates)
cityInput.addEventListener('keyup', e => e.Key === "Enter" && getCityCoordinates());
